var express = require('express');
var router = express.Router();
const mongoose = require('mongoose');
const passportLocalMongoose = require('passport-local-mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/popcile');

/* GET users listing. */
const userSchema = new mongoose.Schema({
  username: String,
  password:String,
  secret: String,
});
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});
userSchema.plugin(passportLocalMongoose);
module.exports = mongoose.model('user', userSchema);
