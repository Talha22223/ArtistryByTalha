var express = require('express');
const passport = require('passport');
var router = express.Router();
const localStrategy = require("passport-local");
const userModel = require('./users');
passport.use(new localStrategy(userModel.authenticate()));
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render("index");
});
router.get("/login", function(req, res, next) {
  res.render("login");
});
router.get("/profile",isloggedIn,function(req,res){
  res.render("profilee", { user: req.user });
})
router.post('/register',function(req,res){
 var userdata= new userModel({
  username: req.body.username,
  secret:req.body.secret
 });

userModel.register(userdata,req.body.password)
.then(function(registereduser){
  passport.authenticate("local")(req,res,function(){
    res.redirect("/profile")
  })
})
.catch(function(err){
  console.log("Registration error:", err);
  if(err.name === 'UserExistsError') {
    res.render('index', { error: 'Username already exists. Please choose a different username.' });
  } else {
    res.render('index', { error: 'Registration failed. Please try again.' });
  }
})
})
router.post("/login",passport.authenticate("local",{
  successRedirect:"/profile",
  failureRedirect:'/login-failed'
}),function(req,res){});

router.get("/login-failed", function(req, res) {
  res.render("login", { error: "Invalid username or password. Please try again." });
});
router.get("/logout",function(req,res,next){
  req.logout(function(err){
    if(err){
      return next(err);
    };
    res.redirect("/");
    
  });
});
function isloggedIn(req,res,next){
  if(req.isAuthenticated()){
    return next();
  }
  res.redirect("/login");
}

module.exports = router;
